import pymysql
con=pymysql.connect(host='brkpzsiaapoqbvkjgqjc-mysql.services.clever-cloud.com',user='utgl4nnzzdri7acb',password='UWu2rZkbss4I6YBEuB6z',database='brkpzsiaapoqbvkjgqjc')
curs=con.cursor()

prid=int(input("enter product id \n"))
mdlnm=input("Enter the Model name \n")
cp=input("Enter the company name \n")
cont=input("Enter the connectivity 4G/5G \n")
rm=input("Enter the RAM  \n")
ro=input("Enter the R0M  \n")
cl=input("Enter the colur of mobile  \n")
sc=(input("Enter the screen size  \n"))
bt=input("Enter the battery specs  \n")
pr=input("Enter the processor  \n")
pc=int(input("Enter the price of mobile  \n"))
rat=input("Enter the Rating of mobile  \n")
pur=input("Enter the purpose of Mobile \n")



try:
  
    
    curs.execute("INSERT INTO MOBILES VALUES (%d,'%s','%s','%s','%s','%s','%s','%s','%s','%s','%d','%s','%s')" %(prid,mdlnm,cp,cont,rm,ro,cl,sc,bt,pr,pc,rat,pur))
    con.commit()
    #curs.execute("INSERT INTO MOBILES values (105,'mi','mi','4G',4,64,'black',6,'4000mah','2.6ghz',10000,'4.6')")
    #con.commit()
    print("Data inserted sucessfully")

except :
    print("Data couldn't insert")


con.close()    

