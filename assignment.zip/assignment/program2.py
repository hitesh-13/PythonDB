import pymysql

con=pymysql.connect(host='brkpzsiaapoqbvkjgqjc-mysql.services.clever-cloud.com',user='utgl4nnzzdri7acb',password='UWu2rZkbss4I6YBEuB6z',database='brkpzsiaapoqbvkjgqjc')
curs=con.cursor()

curs.execute("select * from MOBILES ")
data=curs.fetchall()
for x in data:
    print(x)



con.close()
