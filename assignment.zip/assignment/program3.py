import pymysql

con=pymysql.connect(host='brkpzsiaapoqbvkjgqjc-mysql.services.clever-cloud.com',user='utgl4nnzzdri7acb',password='UWu2rZkbss4I6YBEuB6z',database='brkpzsiaapoqbvkjgqjc')
curs=con.cursor()

mdlnm=input("enter the model name of mobile \n")

curs.execute("select * from MOBILES where modelname='%s' " %(mdlnm))
try:

    x=curs.fetchone()
#for x in data:
    print("Model name ="+x[1])
    print("Company name ="+x[2])
    print("Connectivity ="+x[3])
    print("RAM ="+x[4]+"GB")
    print("ROM  ="+x[5]+"GB")
    print("colour ="+x[6])
    print("Battery ="+x[7]+"mA")
    print("Processor ="+x[8]+"gHZ")
    print("Rating ="+x[11])
    print("price ="+str(x[10]) )   

except:
    print("Not found")


con.close()    