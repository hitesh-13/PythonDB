import pymysql

con=pymysql.connect(host='brkpzsiaapoqbvkjgqjc-mysql.services.clever-cloud.com',user='utgl4nnzzdri7acb',password='UWu2rZkbss4I6YBEuB6z',database='brkpzsiaapoqbvkjgqjc')
curs=con.cursor()

cp=input("enter the company name of mobile \n")

curs.execute("select * from MOBILES where company='%s' order by price " %(cp))
data=curs.fetchall()
for x in data:
    print(x)



con.close()