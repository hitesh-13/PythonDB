import pymysql

con=pymysql.connect(host='brkpzsiaapoqbvkjgqjc-mysql.services.clever-cloud.com',user='utgl4nnzzdri7acb',password='UWu2rZkbss4I6YBEuB6z',database='brkpzsiaapoqbvkjgqjc')
curs=con.cursor()

pid=int(input("enter the product id of mobile \n"))
npc=int(input("Enter new price of mobile \n "))

try:

    curs.execute("update MOBILES set price='%d' where proid='%d'  " %(npc,pid))
    con.commit()
    print("Price updated sucessfully")

except:
    print("Mobile does not exists")    

con.close()    