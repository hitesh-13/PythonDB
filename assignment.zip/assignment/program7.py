import pymysql

con=pymysql.connect(host='brkpzsiaapoqbvkjgqjc-mysql.services.clever-cloud.com',user='utgl4nnzzdri7acb',password='UWu2rZkbss4I6YBEuB6z',database='brkpzsiaapoqbvkjgqjc')
curs=con.cursor()

rm=input("enter the RAM of mobile(GB) \n")
ro=input("enter the ROM of mobile(GB) \n")

try:
    curs.execute("select * from MOBILES where ram='%s' and rom='%s'" %(rm,ro))
    data=curs.fetchall()
    for x in data:
        print(x)




except:
    print("Mobile not found ")


con.close()    
