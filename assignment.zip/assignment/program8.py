import pymysql

con=pymysql.connect(host='brkpzsiaapoqbvkjgqjc-mysql.services.clever-cloud.com',user='utgl4nnzzdri7acb',password='UWu2rZkbss4I6YBEuB6z',database='brkpzsiaapoqbvkjgqjc')
curs=con.cursor()

try:

    curs.execute("alter table MOBILES add purpose varchar(50)")
    con.commit()
    print("Update Sucessfully")

except:
    print("update failed")    


con.close()