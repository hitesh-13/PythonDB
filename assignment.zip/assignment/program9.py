import pymysql

con=pymysql.connect(host='brkpzsiaapoqbvkjgqjc-mysql.services.clever-cloud.com',user='utgl4nnzzdri7acb',password='UWu2rZkbss4I6YBEuB6z',database='brkpzsiaapoqbvkjgqjc')
curs=con.cursor()

mdlnm=input("enter the model name of mobile \n")
pur=input("Enter the purpose of Mobile(Gaming,Social,etc..) \n")

try:
    curs.execute("update MOBILES set purpose='%s' where modelname='%s'" %(pur,mdlnm))
    con.commit()
    print("Purpose Updated")

except:
    print("update failed") 

con.close()       