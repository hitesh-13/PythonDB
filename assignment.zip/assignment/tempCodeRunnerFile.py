con=pymysql.connect(host='brkpzsiaapoqbvkjgqjc-mysql.services.clever-cloud.com',user='utgl4nnzzdri7acb',password='UWu2rZkbss4I6YBEuB6z',database='brkpzsiaapoqbvkjgqjc')
curs=con.cursor()